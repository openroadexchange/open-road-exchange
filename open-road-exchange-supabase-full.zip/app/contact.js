export default function Contact(){ return (<div className='max-w-4xl mx-auto p-8'><h1 className='text-2xl font-bold'>Contact</h1><p className='mt-3'>Email: info@openroadexchange.com</p></div>)}
